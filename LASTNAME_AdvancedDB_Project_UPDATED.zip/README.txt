Contents: schema.sql, procedures.sql, functions.sql, triggers.sql, sample_queries.sql, erd.puml, Technical_Report.md
Run schema.sql first, then procedures/functions/triggers, then sample queries.
